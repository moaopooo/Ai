
let history = [];
const historyDiv = document.getElementById("history");
const predictionEl = document.getElementById("prediction");
const statsEl = document.getElementById("stats");

function recordResult(result) {
  history.push(result);
  updateDisplay();
  saveToLocal();
}

function reset() {
  history = [];
  updateDisplay();
  localStorage.removeItem("baccarat_history");
}

function updateDisplay() {
  historyDiv.innerHTML = "歷史紀錄：" + history.join(" → ");

  let countBanker = history.filter(r => r === '莊').length;
  let countPlayer = history.filter(r => r === '閒').length;
  let total = history.length;

  statsEl.innerText = total > 0
    ? `莊：${((countBanker / total) * 100).toFixed(1)}%　閒：${((countPlayer / total) * 100).toFixed(1)}%`
    : "勝率統計：-";

  let last3 = history.slice(-3);
  if (last3.length === 3 && last3.every(r => r === "莊")) {
    predictionEl.innerText = "AI 預測：下一局可能為『閒』（反轉）";
  } else if (last3.length === 3 && last3.every(r => r === "閒")) {
    predictionEl.innerText = "AI 預測：下一局可能為『莊』（反轉）";
  } else {
    predictionEl.innerText = "AI 預測：尚無明確趨勢";
  }
}

function saveToLocal() {
  localStorage.setItem("baccarat_history", JSON.stringify(history));
}

function loadFromLocal() {
  const saved = localStorage.getItem("baccarat_history");
  if (saved) {
    history = JSON.parse(saved);
    updateDisplay();
  }
}

loadFromLocal();
